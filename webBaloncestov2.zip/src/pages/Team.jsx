import React, { useState } from 'react';
import { players } from '../data/players';

const Team = () => {
  const [activeCategory, setActiveCategory] = useState('senior');

  const filteredPlayers = players.filter(player => player.category === activeCategory);

  const categories = [
    { id: 'senior', name: 'Equipo Senior' },
    { id: 'junior', name: 'Equipo Junior' },
    { id: 'youth', name: 'Cantera' },
    { id: 'staff', name: 'Cuerpo Técnico' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8 md:py-12">
      <div className="container mx-auto px-4">
        {/* Page Title */}
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-deepGreen mb-2">Nuestro Equipo</h1>
          <div className="w-24 h-1 bg-gold mx-auto mb-4"></div>
          <p className="text-gray-700 max-w-3xl mx-auto">
            Conoce a los jugadores y al cuerpo técnico que forman parte de CB Cártama.
            Un gran equipo de profesionales comprometidos con el baloncesto.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="mb-8 flex flex-wrap justify-center">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-6 py-3 mx-1 mb-2 rounded-full text-sm md:text-base font-medium transition-colors ${
                activeCategory === category.id 
                  ? 'bg-deepGreen text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Player Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredPlayers.map(player => (
            <div key={player.id} className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all">
              <div className="aspect-w-3 aspect-h-4 relative">
                <img 
                  src={player.image} 
                  alt={player.name} 
                  className="object-cover w-full h-full"
                />
                <div className="absolute bottom-0 w-full bg-gradient-to-t from-[rgba(12,69,33,0.8)] to-transparent p-4">
                  <div className="text-white">
                    {player.number && (
                      <span className="bg-gold text-deepGreen text-lg font-bold px-2 py-1 rounded-md mr-2">
                        #{player.number}
                      </span>
                    )}
                    <span className="font-bold text-lg">{player.name}</span>
                  </div>
                </div>
              </div>
              <div className="p-4">
                {player.position && (
                  <div className="mb-2 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    <span className="text-gray-800">{player.position}</span>
                  </div>
                )}
                {player.height && (
                  <div className="mb-2 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                    <span className="text-gray-800">{player.height} cm</span>
                  </div>
                )}
                {player.age && (
                  <div className="mb-2 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <span className="text-gray-800">{player.age} años</span>
                  </div>
                )}
                {player.role && (
                  <div className="mb-2 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                    <span className="text-gray-800">{player.role}</span>
                  </div>
                )}
                {player.experience && (
                  <div className="mb-2 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-gray-800">{player.experience} años de experiencia</span>
                  </div>
                )}
                <p className="text-gray-600 text-sm mt-2">{player.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Team;