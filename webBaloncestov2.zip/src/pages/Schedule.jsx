// src/pages/Schedule.jsx
export default function Schedule() {
  return (
    <div className="flex items-center justify-center h-screen">
      <h1 className="text-3xl font-bold text-gray-700">Próximamente</h1>
    </div>
  );
}