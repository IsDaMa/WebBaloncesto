export default function AdminSettings() {
  return (
    <div className="admin-content">
      <h1 className="text-2xl font-bold mb-6">Configuración del Sistema</h1>
      <div className="admin-card">
        {/* Aquí irían los formularios de configuración */}
        <p>Configuraciones administrativas</p>
      </div>
    </div>
  );
}